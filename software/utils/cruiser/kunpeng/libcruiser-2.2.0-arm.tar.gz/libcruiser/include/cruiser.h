/**
 * ==================================================================
 *  Copyright (c) 2023-2024, Kirky.X, All rights reserved.
 *  Prohibit the use of code in any form for any purpose!
 *  The final interpretation power of this code is owned by Kirky.X!
 * ===================================================================
 *  AUTHOR: Kirky.X
 *  DATE:   2023.11.09
 */

/**
 * Hash the specified variable md5 and output it
 *
 * @param data    : Pointer to the starting address of the value
 * @param len_data: The length of the value
 * @param type    : The type of the value
 * @param flag    : The flag of the value
 * @param rank    : The rank number specified by user
 *                  -1: All ranks will be printed
 *                  0: Master rank will be printed
 *                  N+: Special rank will be printed
 * @return NULL
 */
void Hash(void *data, const char *name_data, int type, int len_data, const char *flag, int rank);

/**
 * External exposure interface
 *
 * @param data    : Pointer to the starting address of the value
 * @param len_data: The length of the value
 * @param type    : The type of the value
 * @param flag    : The flag of the value
 * @param len_flag: The length of the flag
 * @param rank    : The rank number specified by user
 * @return NULL
 */
void Nan(void *data, const char *name_data, int type, int len_data, const char *flag, int rank);

/**
 * Simultaneously calling the hash interface and NaN interface
 *
 * @param data    : Pointer to the starting address of the value
 * @param len_data: The length of the value
 * @param type    : The type of the value
 * @param flag    : The flag of the value
 * @param rank    : The rank number specified by user
 * @return NULL
 */
void Cruiser(void *data, const char *name_data, int type, int len_data, const char *flag, int rank);
